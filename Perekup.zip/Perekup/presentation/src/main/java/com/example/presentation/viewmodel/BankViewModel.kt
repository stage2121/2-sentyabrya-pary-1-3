package com.example.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.domain.model.Player
import com.example.domain.repository.PlayerRepository
import com.example.domain.usecase.TakeLoanUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class BankViewModel @Inject constructor(
    private val playerRepository: PlayerRepository,
    private val takeLoanUseCase: TakeLoanUseCase
) : ViewModel() {

    val playerState: StateFlow<Player?> = playerRepository.getPlayerFlow()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = null
        )

    suspend fun takeLoan(amount: Long): String {
        val result = takeLoanUseCase(amount)
        return if (result.isSuccess) "Кредит на $amount ₽ успешно получен!"
        else result.exceptionOrNull()?.message ?: "Ошибка"
    }
}