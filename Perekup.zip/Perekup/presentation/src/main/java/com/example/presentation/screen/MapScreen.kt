package com.example.presentation.screen

import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.example.presentation.components.MapPin

@Composable
fun MapScreen(
    onNavigate: (String) -> Unit = {}
) {
    val context = LocalContext.current

    // Ищем картинку "map_background" в ресурсах приложения (модуль app)
    val imageResId = context.resources.getIdentifier(
        "map_background",
        "drawable",
        context.packageName
    )

    Box(modifier = Modifier.fillMaxSize()) {
        // Фон карты
        if (imageResId != 0) {
            Image(
                painter = painterResource(id = imageResId),
                contentDescription = "Карта города",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            // Если картинка не найдена, показываем серый фон
            Box(modifier = Modifier.fillMaxSize().background(Color.LightGray))
        }

        // 1. Гараж
        MapPin(
            title = "Гараж",
            icon = Icons.Default.Home,
            color = Color(0xFF00897B),
            modifier = Modifier.offset(x = 40.dp, y = 100.dp),
            onClick = { onNavigate("garage") }
        )

        // 2. Доска объявлений
        MapPin(
            title = "Доска",
            icon = Icons.AutoMirrored.Filled.List,
            color = Color(0xFFD32F2F),
            modifier = Modifier.offset(x = 200.dp, y = 80.dp),
            onClick = { onNavigate("board") }
        )

        // 3. СТО
        MapPin(
            title = "СТО",
            icon = Icons.Default.Build,
            color = Color(0xFF1976D2),
            modifier = Modifier.offset(x = 280.dp, y = 250.dp),
            onClick = { Toast.makeText(context, "Ремонт авто (в разработке)", Toast.LENGTH_SHORT).show() }
        )

        // 4. Магазин запчастей
        MapPin(
            title = "Магазин",
            icon = Icons.Default.ShoppingCart,
            color = Color(0xFFF57C00),
            modifier = Modifier.offset(x = 50.dp, y = 350.dp),
            onClick = { onNavigate("shop") }
        )

        // 5. Металлоприемка
        MapPin(
            title = "Металл",
            icon = Icons.Default.Delete,
            color = Color(0xFF757575),
            modifier = Modifier.offset(x = 160.dp, y = 450.dp),
            onClick = { onNavigate("scrap") } // <-- Ведем на экран металлоприемки
        )

        // 6. Банк
        MapPin(
            title = "Банк",
            icon = Icons.Default.AccountBalance,
            color = Color(0xFF8E24AA),
            modifier = Modifier.offset(x = 250.dp, y = 550.dp),
            onClick = { onNavigate("bank") }
        )
    }
}