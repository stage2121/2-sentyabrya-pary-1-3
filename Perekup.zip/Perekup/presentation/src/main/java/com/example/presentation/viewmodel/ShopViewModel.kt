package com.example.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.domain.model.DefectCategory
import com.example.domain.model.Quality
import com.example.domain.usecase.BuyPartUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ShopViewModel @Inject constructor(
    private val buyPartUseCase: BuyPartUseCase
) : ViewModel() {

    suspend fun buyPart(category: DefectCategory, quality: Quality, price: Long): String {
        val result = buyPartUseCase(category, quality, price)
        return if (result.isSuccess) "Запчасть куплена!"
        else result.exceptionOrNull()?.message ?: "Ошибка покупки"
    }
}