package com.example.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.domain.repository.CarRepository
import com.example.domain.usecase.BuyCarUseCase
import com.example.presentation.screen.ChatMessage
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ChatViewModel @Inject constructor(
    private val buyCarUseCase: BuyCarUseCase,
    private val carRepository: CarRepository
) : ViewModel() {

    private var sellerMinPrice: Long = 0
    private var attempts = 0

    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    private val _isDealClosed = MutableStateFlow(false)
    val isDealClosed: StateFlow<Boolean> = _isDealClosed.asStateFlow()

    private val _agreedPrice = MutableStateFlow(0L)
    val agreedPrice: StateFlow<Long> = _agreedPrice.asStateFlow()

    fun resetChat() {
        _messages.value = emptyList()
        _isDealClosed.value = false
        _agreedPrice.value = 0L
        attempts = 0
        sellerMinPrice = 0
        _lastBotOffer.value = 0L
    }

    fun initChat(sellerPrice: Long, carName: String) {
        sellerMinPrice = (sellerPrice * 0.9).toLong()
        _messages.value = listOf(
            ChatMessage("Привет! Продаю $carName. Цена: $sellerPrice ₽. Торг возможен.", false)
        )
    }

    private val _lastBotOffer = MutableStateFlow(0L)
    val lastBotOffer: StateFlow<Long> = _lastBotOffer.asStateFlow()


    fun makeOffer(offerText: String) {
        val offer = offerText.toLongOrNull() ?: return
        if (offer <= 0) return

        attempts++
        val newMessages = _messages.value.toMutableList()
        newMessages.add(ChatMessage("Предлагаю $offer ₽", true))
        _messages.value = newMessages

        viewModelScope.launch {
            delay(1000) // Имитация "печатает..."

            val botReply = when {
                attempts > 4 -> {
                    _isDealClosed.value = true
                    _agreedPrice.value = 0
                    "Слушай, ты меня уже достал торговаться. Сделки не будет. Пока!"
                }
                offer >= sellerMinPrice -> {
                    _isDealClosed.value = true
                    _agreedPrice.value = offer
                    "По рукам! Забирай за $offer ₽. Машина твоя."
                }
                offer < sellerMinPrice * 0.7 -> {
                    "Ты что, издеваешься? Это слишком мало. Давай серьезнее."
                }
                else -> {
                    val counterOffer = (offer + sellerMinPrice) / 2
                    _lastBotOffer.value = counterOffer
                    "Не пойдет. Могу уступить до $counterOffer ₽. Идет?"
                }
            }

            val updatedMessages = _messages.value.toMutableList()
            updatedMessages.add(ChatMessage(botReply, false))
            _messages.value = updatedMessages
        }
    }

    suspend fun buyCar(carId: String, finalPrice: Long): String {
        val car = carRepository.getCarById(carId)
        if (car == null) return "Ошибка: машина не найдена"

        val result = buyCarUseCase(car, finalPrice)
        return if (result.isSuccess) {
            "Авто куплено!"
        } else {
            result.exceptionOrNull()?.message ?: "Ошибка покупки"
        }
    }
}