package com.example.presentation.components

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.time.GameTime
import com.example.domain.model.Player

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GameTopBar(onNewGameClick: () -> Unit,
    player: Player?,
    carsCount: Int, // Пока передадим 0, позже свяжем с БД
) {
    TopAppBar(
        title = {
            if (player != null) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.MonetizationOn, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = "${player.balance} ₽", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Warning, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.error)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = "Долг: ${player.debt} ₽", fontSize = 12.sp, color = MaterialTheme.colorScheme.error)
                    }
                }
            } else {
                Text("Загрузка...")
            }
        },
        actions = {
            if (player != null) {
                // Время
                Text(
                    text = "День ${GameTime.getDay(player.gameHour)} | ${GameTime.getHour(player.gameHour)}:00",
                    fontSize = 14.sp,
                    modifier = Modifier.padding(end = 8.dp)
                )

                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(end = 8.dp)) {
                    Icon(Icons.Default.DirectionsCar, contentDescription = null, modifier = Modifier.size(16.dp))
                    Text(" $carsCount", fontSize = 14.sp)
                }

                // Кнопка "Новая игра"
                IconButton(onClick = onNewGameClick) {
                    Icon(Icons.Default.Refresh, contentDescription = "Новая игра")
                }

                // Кол-во авто
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(end = 8.dp)) {
                    Icon(Icons.Default.DirectionsCar, contentDescription = null, modifier = Modifier.size(16.dp))
                    Text(" $carsCount", fontSize = 14.sp)
                }
            }
        },
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    )
}