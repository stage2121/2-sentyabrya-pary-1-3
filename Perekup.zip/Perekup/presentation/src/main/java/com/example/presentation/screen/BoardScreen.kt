package com.example.presentation.screen

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.presentation.viewmodel.BoardViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BoardScreen(
    viewModel: BoardViewModel = hiltViewModel()
) {
    val listings by viewModel.listings.collectAsStateWithLifecycle()
    val isLoading by viewModel.isLoading.collectAsStateWithLifecycle()

    var activeChat by remember { mutableStateOf<BoardUiModel?>(null) }

    if (activeChat != null) {
        // Экран Чата
        Column(modifier = Modifier.fillMaxSize()) {
            TopAppBar(
                title = { Text("Торг: ${activeChat!!.brand} ${activeChat!!.model}") },
                navigationIcon = {
                    IconButton(onClick = { activeChat = null }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Назад")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                )
            )

            ChatScreen(
                carId = activeChat!!.id,
                carName = "${activeChat!!.brand} ${activeChat!!.model}",
                sellerPrice = activeChat!!.price,
                onPurchaseSuccess = {
                    // После покупки машина меняет ownerType на PLAYER,
                    // и автоматически исчезает из потока MARKET
                    activeChat = null
                }
            )
        }
    } else {
        // Экран Доски объявлений
        Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
            Text(
                text = "Доска объявлений",
                style = MaterialTheme.typography.headlineMedium,
                modifier = Modifier.padding(bottom = 16.dp)
            )

            if (isLoading) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            } else if (listings.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("На доске пока нет объявлений", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(listings) { car ->
                        CarCard(
                            car = car,
                            onBuyClick = { activeChat = car }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun CarCard(
    car: BoardUiModel,
    onBuyClick: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .background(Color.LightGray, RoundedCornerShape(8.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text("ФОТО", color = Color.Gray, style = MaterialTheme.typography.bodySmall)
            }

            Spacer(modifier = Modifier.width(16.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "${car.brand} ${car.model}",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "${car.year} г. | ${car.mileage} км",
                    style = MaterialTheme.typography.bodyMedium
                )
                Text(
                    text = "Состояние: ${car.conditionText}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.secondary
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "${car.price} ₽",
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold
                )
            }

            Button(
                onClick = onBuyClick,
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("Купить")
            }
        }
    }
}