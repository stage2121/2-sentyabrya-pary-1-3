package com.example.presentation.screen

data class BoardUiModel(
    val id: String,
    val brand: String,
    val model: String,
    val year: Int,
    val mileage: Int,
    val price: Long,
    val conditionText: String,
    val photoResName: String // Имя картинки для будущего
)