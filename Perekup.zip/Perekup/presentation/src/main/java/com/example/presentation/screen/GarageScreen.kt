package com.example.presentation.screen

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.domain.model.Car
import com.example.presentation.viewmodel.GarageViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GarageScreen(
    viewModel: GarageViewModel = hiltViewModel()
) {
    val cars by viewModel.cars.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var activeSaleCar by remember { mutableStateOf<Car?>(null) }

    if (activeSaleCar != null) {
        // Экран Чата с Покупателем
        Column(modifier = Modifier.fillMaxSize()) {
            TopAppBar(
                title = { Text("Продажа: ${activeSaleCar!!.brand} ${activeSaleCar!!.model}") },
                navigationIcon = {
                    IconButton(onClick = { activeSaleCar = null }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Назад")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                )
            )

            BuyerChatScreen(
                car = activeSaleCar!!,
                playerAskingPrice = (activeSaleCar!!.baseValue * 1.2).toLong(),
                onSaleSuccess = {
                    Toast.makeText(context, "Машина продана!", Toast.LENGTH_SHORT).show()
                    activeSaleCar = null
                }
            )
        }
    } else {
        // Экран Гаража (Список машин)
        Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
            Text(
                text = "Мой Гараж",
                style = MaterialTheme.typography.headlineMedium,
                modifier = Modifier.padding(bottom = 16.dp)
            )

            if (cars.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("В гараже пока пусто.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(cars) { car ->
                        GarageCarCard(
                            car = car,
                            onRepairClick = {
                                coroutineScope.launch {
                                    val msg = viewModel.repairCar(car)
                                    Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                                }
                            },
                            onSellClick = { activeSaleCar = car },
                            onScrapClick = { Toast.makeText(context, "В разработке", Toast.LENGTH_SHORT).show() }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun GarageCarCard(
    car: Car,
    onRepairClick: () -> Unit,
    onSellClick: () -> Unit,
    onScrapClick: () -> Unit
) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text("${car.brand} ${car.model}", style = MaterialTheme.typography.titleMedium)
            Text("${car.year} г. | ${car.mileage} км")
            Text("Состояние: ${car.condition}/100")

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(onClick = onRepairClick, modifier = Modifier.weight(1f)) { Text("Ремонт") }
                Button(onClick = onSellClick, modifier = Modifier.weight(1f)) { Text("Продать") }
                OutlinedButton(onClick = onScrapClick, modifier = Modifier.weight(1f)) { Text("Металл") }
            }
        }
    }
}