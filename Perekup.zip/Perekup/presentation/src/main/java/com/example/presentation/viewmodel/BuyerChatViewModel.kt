package com.example.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.domain.model.Car
import com.example.domain.repository.CarRepository
import com.example.domain.repository.PlayerRepository
import com.example.presentation.screen.ChatMessage
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class BuyerChatViewModel @Inject constructor(
    private val playerRepository: PlayerRepository,
    private val carRepository: CarRepository
) : ViewModel() {

    private var buyerMaxPrice: Long = 0
    private var attempts = 0
    private var carIdToSell: String = ""
    private var askingPrice: Long = 0

    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    private val _isDealClosed = MutableStateFlow(false)
    val isDealClosed: StateFlow<Boolean> = _isDealClosed.asStateFlow()

    private val _agreedPrice = MutableStateFlow(0L)
    val agreedPrice: StateFlow<Long> = _agreedPrice.asStateFlow()

    private val _lastBotOffer = MutableStateFlow(0L)
    val lastBotOffer: StateFlow<Long> = _lastBotOffer.asStateFlow()

    fun resetChat() {
        _messages.value = emptyList()
        _isDealClosed.value = false
        _agreedPrice.value = 0L
        _lastBotOffer.value = 0L
        attempts = 0
        buyerMaxPrice = 0
        askingPrice = 0
    }

    fun initBuyerChat(car: Car, playerAskingPrice: Long) {
        carIdToSell = car.id
        askingPrice = playerAskingPrice
        buyerMaxPrice = (playerAskingPrice * 0.85).toLong()

        _messages.value = listOf(
            ChatMessage("Здравствуйте! Увидел ваше объявление. Готов обсудить цену.", false)
        )
    }

    // Игрок вводит свою цену
    fun makeOffer(offerText: String) {
        val offer = offerText.toLongOrNull() ?: return
        if (offer <= 0) return

        attempts++
        val newMessages = _messages.value.toMutableList()
        newMessages.add(ChatMessage("Я хочу получить $offer ₽", true))
        _messages.value = newMessages

        viewModelScope.launch {
            delay(1000)

            val botReply = when {
                attempts > 4 -> {
                    _isDealClosed.value = true
                    "Слишком долго. Я лучше другую машину посмотрю. До свидания."
                }
                offer <= buyerMaxPrice -> {
                    _isDealClosed.value = true
                    _agreedPrice.value = offer
                    "Отлично, меня устраивает! Забираю за $offer ₽."
                }
                offer > askingPrice * 1.1 -> {
                    "Это дороговато для меня. Давайте скинем."
                }
                else -> {
                    val counterOffer = (offer + buyerMaxPrice) / 2
                    _lastBotOffer.value = counterOffer
                    "Я готов дать только $counterOffer ₽. Отдадите?"
                }
            }

            val updatedMessages = _messages.value.toMutableList()
            updatedMessages.add(ChatMessage(botReply, false))
            _messages.value = updatedMessages
        }
    }

    // Игрок соглашается на цену бота (нажатие на кнопку)
    fun acceptBotOffer() {
        val price = _lastBotOffer.value
        if (price > 0) {
            _isDealClosed.value = true
            _agreedPrice.value = price

            val newMessages = _messages.value.toMutableList()
            newMessages.add(ChatMessage("Хорошо, я согласен на $price ₽.", true))
            newMessages.add(ChatMessage("Отлично! Забираю за $price ₽.", false))
            _messages.value = newMessages
        }
    }

    suspend fun sellCarToBuyer(): String {
        val player = playerRepository.getPlayer() ?: return "Игрок не найден"
        val price = _agreedPrice.value

        // 1. Начисляем деньги игроку
        playerRepository.updateBalance(player.id, player.balance + price)

        // 2. Удаляем машину из базы
        carRepository.deleteCar(carIdToSell)

        return "Машина продана за $price ₽!"
    }
}