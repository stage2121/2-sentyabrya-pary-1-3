package com.example.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.domain.model.Player
import com.example.domain.repository.PlayerRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class MainViewModel @Inject constructor(
    private val playerRepository: PlayerRepository
) : ViewModel() {

    val playerState: StateFlow<Player?> = playerRepository.getPlayerFlow()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = null
        )

    fun startNewGame() {
        viewModelScope.launch {
            val newPlayer = Player(
                id = "player_1",
                name = "Перекуп",
                balance = 550_000L, // Стартовый баланс
                debt = 0L,
                garageId = null,
                reputation = 10,
                gameHour = 0L
            )
            playerRepository.savePlayer(newPlayer)
        }
    }
}