package com.example.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.domain.model.Car
import com.example.domain.repository.CarRepository
import com.example.domain.usecase.RepairCarUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import javax.inject.Inject

@HiltViewModel
class GarageViewModel @Inject constructor(
    private val carRepository: CarRepository,
    private val repairCarUseCase: RepairCarUseCase
) : ViewModel() {

    val cars: StateFlow<List<Car>> = carRepository.getPlayerCarsFlow()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    suspend fun repairCar(car: Car): String {
        val repairCost = (car.baseValue * 0.10).toLong()
        val result = repairCarUseCase(car, repairCost)
        return if (result.isSuccess) "Авто отремонтировано за $repairCost ₽!"
        else result.exceptionOrNull()?.message ?: "Ошибка ремонта"
    }
}