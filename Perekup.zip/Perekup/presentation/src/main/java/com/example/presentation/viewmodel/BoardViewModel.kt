package com.example.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.domain.model.Car
import com.example.domain.repository.CarRepository
import com.example.presentation.screen.BoardUiModel
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class BoardViewModel @Inject constructor(
    private val carRepository: CarRepository
) : ViewModel() {

    private val _listings = MutableStateFlow<List<BoardUiModel>>(emptyList())
    val listings: StateFlow<List<BoardUiModel>> = _listings.asStateFlow()

    private val _isLoading = MutableStateFlow(true)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    init {
        // Подписываемся на поток машин с рынка
        viewModelScope.launch {
            carRepository.getMarketCarsFlow().collect { cars ->
                _listings.value = cars.map { car ->
                    BoardUiModel(
                        id = car.id,
                        brand = car.brand,
                        model = car.model,
                        year = car.year,
                        mileage = car.mileage,
                        price = car.currentPrice ?: car.baseValue,
                        conditionText = "Хорошее", // Для MVP
                        photoResName = "car_photo"
                    )
                }
                _isLoading.value = false
            }
        }
    }
}