package com.example.presentation.screen

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.domain.model.Car
import com.example.presentation.viewmodel.BuyerChatViewModel
import kotlinx.coroutines.launch

@Composable
fun BuyerChatScreen(
    car: Car,
    playerAskingPrice: Long,
    onSaleSuccess: () -> Unit,
    viewModel: BuyerChatViewModel = hiltViewModel()
) {
    val messages by viewModel.messages.collectAsStateWithLifecycle()
    val isDealClosed by viewModel.isDealClosed.collectAsStateWithLifecycle()
    val agreedPrice by viewModel.agreedPrice.collectAsStateWithLifecycle()
    val lastBotOffer by viewModel.lastBotOffer.collectAsStateWithLifecycle()

    var inputText by remember { mutableStateOf("") }
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    LaunchedEffect(car.id) {
        viewModel.resetChat()
        viewModel.initBuyerChat(car, playerAskingPrice)
    }

    Column(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier.weight(1f).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(messages) { message -> ChatBubble(message) }
        }

        if (!isDealClosed) {
            // Кнопка "Согласиться", если бот сделал предложение
            if (lastBotOffer > 0) {
                Button(
                    onClick = { viewModel.acceptBotOffer() }, // <-- Вызываем acceptBotOffer
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                ) {
                    Text("Согласиться на $lastBotOffer ₽")
                }
            }

            // Поле ввода
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp)
                    .background(Color.LightGray, RoundedCornerShape(8.dp))
                    .padding(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = inputText,
                    onValueChange = { inputText = it },
                    placeholder = { Text("Назовите цену...") },
                    modifier = Modifier.weight(1f),
                    singleLine = true
                )
                Spacer(modifier = Modifier.width(8.dp))
                IconButton(
                    onClick = {
                        if (inputText.isNotBlank()) {
                            viewModel.makeOffer(inputText)
                            inputText = ""
                        }
                    }
                ) {
                    Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Отправить")
                }
            }
        } else {
            // Сделка закрыта
            if (agreedPrice > 0) {
                Button(
                    onClick = {
                        coroutineScope.launch {
                            val result = viewModel.sellCarToBuyer()
                            Toast.makeText(context, result, Toast.LENGTH_LONG).show()
                            if (result.contains("продана")) {
                                onSaleSuccess()
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth().padding(16.dp)
                ) {
                    Text("Продать за $agreedPrice ₽")
                }
            } else {
                Text(
                    "Сделка не состоялась",
                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                    color = MaterialTheme.colorScheme.error
                )
            }
        }
    }
}