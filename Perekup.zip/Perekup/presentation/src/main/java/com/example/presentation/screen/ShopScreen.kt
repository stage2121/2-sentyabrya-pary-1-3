package com.example.presentation.screen

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.example.domain.model.DefectCategory
import com.example.domain.model.Quality
import com.example.presentation.viewmodel.ShopViewModel
import kotlinx.coroutines.launch

@Composable
fun ShopScreen(
    viewModel: ShopViewModel = hiltViewModel()
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    val categories = listOf(
        DefectCategory.ENGINE to "Двигатель",
        DefectCategory.BODY to "Кузов",
        DefectCategory.SUSPENSION to "Подвеска",
        DefectCategory.ELECTRIC to "Электрика",
        DefectCategory.CONSUMABLE to "Расходники"
    )

    val qualities = listOf(
        Quality.USED to "Б/У",
        Quality.ANALOG to "Аналог",
        Quality.ORIGINAL to "Оригинал"
    )

    val basePrices = mapOf(
        DefectCategory.ENGINE to 8000L,
        DefectCategory.BODY to 5000L,
        DefectCategory.SUSPENSION to 4000L,
        DefectCategory.ELECTRIC to 3000L,
        DefectCategory.CONSUMABLE to 1500L
    )

    val qualityMultipliers = mapOf(
        Quality.USED to 0.4,
        Quality.ANALOG to 0.7,
        Quality.ORIGINAL to 1.0
    )

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("Магазин запчастей", style = MaterialTheme.typography.headlineMedium)
        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(16.dp)) {
            items(categories) { (category, categoryName) ->
                val basePrice = basePrices[category] ?: 0L

                Text(categoryName, style = MaterialTheme.typography.titleLarge)

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    qualities.forEach { (quality, qualityName) ->
                        val multiplier = qualityMultipliers[quality] ?: 1.0
                        val price = (basePrice * multiplier).toLong()

                        Button(
                            onClick = {
                                coroutineScope.launch {
                                    val msg = viewModel.buyPart(category, quality, price)
                                    Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                                }
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(qualityName, style = MaterialTheme.typography.labelSmall)
                                Text("$price ₽", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }
        }
    }
}