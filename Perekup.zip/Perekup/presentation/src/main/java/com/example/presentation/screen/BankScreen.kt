package com.example.presentation.screen

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.presentation.viewmodel.BankViewModel
import kotlinx.coroutines.launch

@Composable
fun BankScreen(
    viewModel: BankViewModel = hiltViewModel()
) {
    val player by viewModel.playerState.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("Банк", style = MaterialTheme.typography.headlineMedium)
        Spacer(modifier = Modifier.height(24.dp))

        if (player != null) {
            // Карточка с текущим балансом, долгом и лимитом
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Ваш баланс: ${player!!.balance} ₽", style = MaterialTheme.typography.titleMedium)
                    Text("Ваш долг: ${player!!.debt} ₽", color = MaterialTheme.colorScheme.error)
                    Text("Репутация: ${player!!.reputation}", style = MaterialTheme.typography.bodyMedium)

                    val creditLimit = 50_000L + (player!!.reputation * 2_000L)
                    val availableCredit = (creditLimit - player!!.debt).coerceAtLeast(0)
                    Text("Доступно к кредиту: $availableCredit ₽", color = MaterialTheme.colorScheme.primary)
                }
            }

            Spacer(modifier = Modifier.height(32.dp))
            Text("Взять кредит:", style = MaterialTheme.typography.titleLarge)
            Spacer(modifier = Modifier.height(16.dp))

            // Кнопки для взятия кредита
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = {
                        coroutineScope.launch {
                            val msg = viewModel.takeLoan(10_000L)
                            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                        }
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Text("10 000 ₽")
                }
                Button(
                    onClick = {
                        coroutineScope.launch {
                            val msg = viewModel.takeLoan(50_000L)
                            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                        }
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Text("50 000 ₽")
                }
                Button(
                    onClick = {
                        coroutineScope.launch {
                            val msg = viewModel.takeLoan(100_000L)
                            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                        }
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Text("100 000 ₽")
                }
            }
        } else {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        }
    }
}