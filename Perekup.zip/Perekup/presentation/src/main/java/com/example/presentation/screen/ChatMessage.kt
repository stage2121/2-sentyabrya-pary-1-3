package com.example.presentation.screen

data class ChatMessage(
    val text: String,
    val isFromPlayer: Boolean // true = сообщение игрока, false = сообщение бота
)