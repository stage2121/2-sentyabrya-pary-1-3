package com.example.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.domain.repository.CarRepository
import com.example.domain.usecase.ScrapCarUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import javax.inject.Inject

@HiltViewModel
class ScrapViewModel @Inject constructor(
    private val scrapCarUseCase: ScrapCarUseCase,
    carRepository: CarRepository
) : ViewModel() {

    // Показываем список машин в гараже для сдачи
    val cars = carRepository.getPlayerCarsFlow()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    suspend fun scrapCar(carId: String): String {
        // Находим машину по ID (упрощенно, для MVP)
        val car = cars.value.find { it.id == carId } ?: return "Машина не найдена"

        val result = scrapCarUseCase(car)
        return if (result.isSuccess) {
            "Машина сдана за ${result.getOrNull()} ₽"
        } else {
            result.exceptionOrNull()?.message ?: "Ошибка сдачи"
        }
    }
}