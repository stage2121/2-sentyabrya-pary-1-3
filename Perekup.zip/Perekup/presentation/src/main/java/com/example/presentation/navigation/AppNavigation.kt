package com.example.presentation.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.presentation.components.GameTopBar
import com.example.presentation.screen.*
import com.example.presentation.viewmodel.MainViewModel

sealed class Screen(val route: String, val title: String, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
    object Map : Screen("map", "Карта", Icons.Default.Map)
    object Board : Screen("board", "Доска", Icons.AutoMirrored.Filled.List)
    object Garage : Screen("garage", "Гараж", Icons.Default.Home)
    object Inventory : Screen("inventory", "Инвентарь", Icons.Default.Build)
    object Bank : Screen("bank", "Банк", Icons.Default.AccountBalance)
    object Shop : Screen("shop", "Магазин", Icons.Default.ShoppingCart)
    object Scrap : Screen("scrap", "Металл", Icons.Default.Delete) // <-- Новый экран
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppNavigation(
    viewModel: MainViewModel = hiltViewModel()
) {
    val navController = rememberNavController()
    val items = listOf(Screen.Map, Screen.Board, Screen.Garage, Screen.Inventory, Screen.Bank)

    val player by viewModel.playerState.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            GameTopBar(
                player = player,
                carsCount = 0,
                onNewGameClick = { viewModel.startNewGame() }
            )
        },
        bottomBar = {
            NavigationBar {
                val navBackStackEntry by navController.currentBackStackEntryAsState()
                val currentDestination = navBackStackEntry?.destination

                items.forEach { screen ->
                    NavigationBarItem(
                        icon = { Icon(screen.icon, contentDescription = screen.title) },
                        label = { Text(screen.title) },
                        selected = currentDestination?.hierarchy?.any { it.route == screen.route } == true,
                        onClick = {
                            navController.navigate(screen.route) {
                                popUpTo(navController.graph.findStartDestination().id) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState = true
                            }
                        }
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Map.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Screen.Map.route) {
                MapScreen(
                    onNavigate = { route ->
                        navController.navigate(route) {
                            popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                            launchSingleTop = true
                            restoreState = true
                        }
                    }
                )
            }
            composable(Screen.Board.route) { BoardScreen() }
            composable(Screen.Garage.route) { GarageScreen() }
            composable(Screen.Inventory.route) { InventoryScreen() }
            composable(Screen.Bank.route) { BankScreen() }
            composable(Screen.Shop.route) { ShopScreen() }
            composable(Screen.Scrap.route) { ScrapScreen() } // <-- Добавлен маршрут металлоприемки
        }
    }
}