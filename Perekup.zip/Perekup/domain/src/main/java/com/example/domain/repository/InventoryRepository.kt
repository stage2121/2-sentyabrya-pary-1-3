package com.example.domain.repository

import com.example.domain.model.DefectCategory
import com.example.domain.model.Quality
import kotlinx.coroutines.flow.Flow

data class InventoryItem(
    val id: String,
    val name: String,
    val category: DefectCategory,
    val quality: Quality,
    val price: Long,
    val quantity: Int
)

interface InventoryRepository {
    fun getInventoryFlow(): Flow<List<InventoryItem>>
    suspend fun addItem(item: InventoryItem)
    suspend fun removeItem(itemId: String)
    suspend fun removeOneItem(itemId: String) // <-- Добавлен метод
}