package com.example.domain.repository

import com.example.domain.model.Car
import kotlinx.coroutines.flow.Flow

interface CarRepository {
    fun getPlayerCarsFlow(): Flow<List<Car>>
    fun getMarketCarsFlow(): Flow<List<Car>> // <-- Новый метод
    suspend fun saveCar(car: Car)
    suspend fun getCarById(id: String): Car?
    suspend fun deleteCar(carId: String)
}