package com.example.domain.model

data class Defect(
    val id: String,
    val category: DefectCategory,
    val severity: Int, // 0..100
    val repaired: Boolean = false
)