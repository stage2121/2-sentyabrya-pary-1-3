package com.example.domain.model

data class Player(
    val id: String,
    val name: String,
    val balance: Long,
    val debt: Long,
    val garageId: String?, // В ТЗ было garagedId, исправляем на правильное
    val reputation: Int,
    val gameHour: Long
)