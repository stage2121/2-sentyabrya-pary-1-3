package com.example.domain.model

enum class DefectCategory {
    ENGINE, BODY, SUSPENSION, ELECTRIC, CONSUMABLE
}