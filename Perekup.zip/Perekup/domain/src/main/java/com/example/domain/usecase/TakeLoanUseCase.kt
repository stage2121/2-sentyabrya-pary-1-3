package com.example.domain.usecase

import com.example.domain.repository.PlayerRepository
import javax.inject.Inject

class TakeLoanUseCase @Inject constructor(
    private val playerRepository: PlayerRepository
) {
    suspend operator fun invoke(amount: Long): Result<Unit> {
        val player = playerRepository.getPlayer() ?: return Result.failure(Exception("Игрок не найден"))

        // Расчет кредитного лимита (из ТЗ)
        val creditLimit = 50_000L + (player.reputation * 2_000L)

        // Проверяем, не превысит ли новый долг лимит
        val newDebt = player.debt + amount
        if (newDebt > creditLimit) {
            return Result.failure(Exception("Превышен лимит кредита. Максимум: $creditLimit ₽. Ваш текущий долг: ${player.debt} ₽"))
        }

        // Выдаем кредит: увеличиваем баланс и долг
        val newBalance = player.balance + amount

        val updatedPlayer = player.copy(balance = newBalance, debt = newDebt)
        playerRepository.savePlayer(updatedPlayer)

        return Result.success(Unit)
    }
}