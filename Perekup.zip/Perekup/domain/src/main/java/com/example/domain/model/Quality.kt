package com.example.domain.model

enum class Quality {
    USED, ANALOG, ORIGINAL
}