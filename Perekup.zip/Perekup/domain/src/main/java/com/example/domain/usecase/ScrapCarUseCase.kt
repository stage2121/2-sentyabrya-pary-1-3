package com.example.domain.usecase

import com.example.domain.model.Car
import com.example.domain.repository.CarRepository
import com.example.domain.repository.PlayerRepository
import javax.inject.Inject

class ScrapCarUseCase @Inject constructor(
    private val playerRepository: PlayerRepository,
    private val carRepository: CarRepository
) {
    suspend operator fun invoke(car: Car): Result<Long> {
        val player = playerRepository.getPlayer() ?: return Result.failure(Exception("Игрок не найден"))

        // Для MVP: считаем 10% от базовой стоимости (без вызова Formulas из core)
        val scrapValue = (car.baseValue * 0.10).toLong()

        // 1. Начисляем деньги
        playerRepository.updateBalance(player.id, player.balance + scrapValue)

        // 2. Удаляем машину из базы
        carRepository.deleteCar(car.id)

        return Result.success(scrapValue)
    }
}