package com.example.domain.usecase

import com.example.domain.model.Car
import com.example.domain.model.OwnerType
import com.example.domain.repository.CarRepository
import com.example.domain.repository.PlayerRepository
import javax.inject.Inject

class BuyCarUseCase @Inject constructor(
    private val playerRepository: PlayerRepository,
    private val carRepository: CarRepository
) {
    suspend operator fun invoke(
        car: Car,
        agreedPrice: Long
    ): Result<Unit> {
        val player = playerRepository.getPlayer() ?: return Result.failure(Exception("Игрок не найден"))

        if (player.balance < agreedPrice) {
            return Result.failure(Exception("Недостаточно средств"))
        }

        // 1. Списываем деньги
        val newBalance = player.balance - agreedPrice
        playerRepository.updateBalance(player.id, newBalance)

        // 2. Добавляем машину игроку
        // (ownerType = PLAYER, currentPrice = null, так как она еще не выставлена)
        val purchasedCar = car.copy(
            ownerType = OwnerType.PLAYER,
            currentPrice = null
        )
        carRepository.saveCar(purchasedCar)

        return Result.success(Unit)
    }
}