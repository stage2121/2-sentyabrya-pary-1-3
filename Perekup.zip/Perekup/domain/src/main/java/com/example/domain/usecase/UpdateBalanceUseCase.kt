package com.example.domain.usecase

import com.example.domain.repository.PlayerRepository
import javax.inject.Inject

class UpdateBalanceUseCase @Inject constructor(
    private val playerRepository: PlayerRepository
) {
    suspend operator fun invoke(playerId: String, newBalance: Long) {
        // Здесь в будущем можно добавить валидацию (например, баланс не может быть < 0)
        if (newBalance < 0) {
            throw IllegalArgumentException("Баланс не может быть отрицательным")
        }
        playerRepository.updateBalance(playerId, newBalance)
    }
}