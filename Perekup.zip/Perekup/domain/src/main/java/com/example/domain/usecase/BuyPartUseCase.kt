package com.example.domain.usecase

import com.example.domain.model.DefectCategory
import com.example.domain.model.Quality
import com.example.domain.repository.InventoryItem
import com.example.domain.repository.InventoryRepository
import com.example.domain.repository.PlayerRepository
import javax.inject.Inject

class BuyPartUseCase @Inject constructor(
    private val playerRepository: PlayerRepository,
    private val inventoryRepository: InventoryRepository
) {
    suspend operator fun invoke(
        category: DefectCategory,
        quality: Quality,
        price: Long
    ): Result<Unit> {
        val player = playerRepository.getPlayer() ?: return Result.failure(Exception("Игрок не найден"))

        if (player.balance < price) {
            return Result.failure(Exception("Недостаточно средств"))
        }

        // 1. Списываем деньги
        playerRepository.updateBalance(player.id, player.balance - price)

        // 2. Добавляем в инвентарь
        val item = InventoryItem(
            id = System.currentTimeMillis().toString(), // Уникальный ID
            name = "${category.name}_${quality.name}",
            category = category,
            quality = quality,
            price = price,
            quantity = 1
        )
        inventoryRepository.addItem(item)

        return Result.success(Unit)
    }
}