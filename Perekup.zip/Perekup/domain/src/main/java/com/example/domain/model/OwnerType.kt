package com.example.domain.model

enum class OwnerType {
    MARKET, PLAYER, BOT
}