package com.example.domain.usecase

import com.example.domain.model.Car
import com.example.domain.repository.CarRepository
import com.example.domain.repository.InventoryRepository
import com.example.domain.repository.PlayerRepository
import kotlinx.coroutines.flow.first
import javax.inject.Inject

class RepairCarUseCase @Inject constructor(
    private val playerRepository: PlayerRepository,
    private val carRepository: CarRepository,
    private val inventoryRepository: InventoryRepository
) {
    suspend operator fun invoke(car: Car, repairCost: Long): Result<Unit> {
        val player = playerRepository.getPlayer() ?: return Result.failure(Exception("Игрок не найден"))

        if (player.balance < repairCost) {
            return Result.failure(Exception("Недостаточно средств для ремонта"))
        }

        // Проверяем, есть ли запчасти в инвентаре
        val inventory = inventoryRepository.getInventoryFlow().first()
        if (inventory.isEmpty()) {
            return Result.failure(Exception("Нет запчастей для ремонта. Купите в магазине."))
        }

        // Берем первую попавшуюся запчасть и списываем её
        val partToRemove = inventory.first()
        inventoryRepository.removeOneItem(partToRemove.id)

        // 1. Списываем деньги
        val newBalance = player.balance - repairCost
        playerRepository.updateBalance(player.id, newBalance)

        // 2. Улучшаем состояние машины
        val repairedCar = car.copy(condition = 100)
        carRepository.saveCar(repairedCar)

        return Result.success(Unit)
    }
}