package com.example.domain.repository

import com.example.domain.model.Player
import kotlinx.coroutines.flow.Flow

interface PlayerRepository {
    fun getPlayerFlow(): Flow<Player?>
    suspend fun getPlayer(): Player?
    suspend fun savePlayer(player: Player)
    suspend fun updateBalance(playerId: String, newBalance: Long)
}