package com.example.domain.model

data class Car(
    val id: String,
    val brand: String,
    val model: String,
    val year: Int,
    val tier: Int, // 1..5, скрытый параметр
    val baseValue: Long, // базовая рыночная стоимость
    val mileage: Int,
    val condition: Int, // 0..100
    val defects: List<Defect> = emptyList(),
    val photos: List<String> = emptyList(),
    val ownerType: OwnerType,
    val currentPrice: Long? = null
)