package com.example.domain.model

enum class ListingStatus {
    ACTIVE, SOLD, EXPIRED
}