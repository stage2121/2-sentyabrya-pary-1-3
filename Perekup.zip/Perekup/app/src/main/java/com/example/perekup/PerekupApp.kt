package com.example.perekup

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class PerekupApp : Application() {
}