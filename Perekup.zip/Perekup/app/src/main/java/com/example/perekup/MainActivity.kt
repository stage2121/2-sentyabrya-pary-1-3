package com.example.perekup

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.lifecycle.lifecycleScope
import com.example.domain.model.Player
import com.example.domain.repository.PlayerRepository
import com.example.presentation.navigation.AppNavigation
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch
import javax.inject.Inject

@AndroidEntryPoint // Важно! Включает Hilt для Activity
class MainActivity : ComponentActivity() {

    @Inject
    lateinit var playerRepository: PlayerRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Временная инициализация игрока
        lifecycleScope.launch {
            val existingPlayer = playerRepository.getPlayer()
            if (existingPlayer == null) {
                val newPlayer = Player(
                    id = "player_1",
                    name = "Перекуп",
                    balance = 550_000L,
                    debt = 0L,
                    garageId = null,
                    reputation = 10,
                    gameHour = 0L // Начинаем с 0-го часа
                )
                playerRepository.savePlayer(newPlayer)
            }
        }

        setContent {
            AppNavigation()
        }
    }
}