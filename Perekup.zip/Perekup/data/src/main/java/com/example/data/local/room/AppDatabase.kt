package com.example.data.local.room

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverter
import androidx.room.TypeConverters
import com.example.data.local.room.dao.CarDao
import com.example.data.local.room.dao.InventoryDao
import com.example.data.local.room.dao.ListingDao
import com.example.data.local.room.dao.PlayerDao
import com.example.data.local.room.entity.*
import com.example.domain.model.DefectCategory
import com.example.domain.model.ListingStatus
import com.example.domain.model.OwnerType
import com.example.domain.model.Quality

class Converters {
    @TypeConverter fun fromOwnerType(value: OwnerType): String = value.name
    @TypeConverter fun toOwnerType(value: String): OwnerType = OwnerType.valueOf(value)

    @TypeConverter fun fromDefectCategory(value: DefectCategory): String = value.name
    @TypeConverter fun toDefectCategory(value: String): DefectCategory = DefectCategory.valueOf(value)

    @TypeConverter fun fromListingStatus(value: ListingStatus): String = value.name
    @TypeConverter fun toListingStatus(value: String): ListingStatus = ListingStatus.valueOf(value)

    @TypeConverter fun fromQuality(value: Quality): String = value.name
    @TypeConverter fun toQuality(value: String): Quality = Quality.valueOf(value)
}

@Database(
    entities = [
        PlayerEntity::class,
        CarEntity::class,
        DefectEntity::class,
        ListingEntity::class,
        InventoryEntity::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun playerDao(): PlayerDao
    abstract fun carDao(): CarDao
    abstract fun listingDao(): ListingDao
    abstract fun inventoryDao(): InventoryDao
}