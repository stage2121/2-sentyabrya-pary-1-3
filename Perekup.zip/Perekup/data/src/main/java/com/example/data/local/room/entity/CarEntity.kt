package com.example.data.local.room.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.domain.model.OwnerType

@Entity(tableName = "cars")
data class CarEntity(
    @PrimaryKey val id: String,
    val brand: String,
    val model: String,
    val year: Int,
    val tier: Int,
    val baseValue: Long,
    val mileage: Int,
    val condition: Int,
    val ownerType: OwnerType, // Room сохранит это как строку (Enum)
    val currentPrice: Long?
)