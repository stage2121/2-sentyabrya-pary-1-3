package com.example.data.local.room.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.domain.model.DefectCategory
import com.example.domain.model.Quality

@Entity(tableName = "inventory")
data class InventoryEntity(
    @PrimaryKey val id: String,
    val name: String,
    val category: DefectCategory,
    val quality: Quality,
    val price: Long,
    val quantity: Int
)