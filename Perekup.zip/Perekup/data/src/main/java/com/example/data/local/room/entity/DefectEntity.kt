package com.example.data.local.room.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import com.example.domain.model.DefectCategory

@Entity(
    tableName = "defects",
    foreignKeys = [
        ForeignKey(
            entity = CarEntity::class,
            parentColumns = ["id"],
            childColumns = ["carId"],
            onDelete = ForeignKey.CASCADE // Если удаляем авто, дефекты удаляются сами
        )
    ],
    indices = [Index(value = ["carId"])]
)
data class DefectEntity(
    @PrimaryKey val id: String,
    val carId: String,
    val category: DefectCategory,
    val severity: Int,
    val repaired: Boolean
)