package com.example.data.repository

import com.example.data.local.room.dao.PlayerDao
import com.example.data.local.room.entity.PlayerEntity
import com.example.domain.model.Player
import com.example.domain.repository.PlayerRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject

class PlayerRepositoryImpl @Inject constructor(
    private val playerDao: PlayerDao
) : PlayerRepository {

    override fun getPlayerFlow(): Flow<Player?> {
        return playerDao.getPlayerFlow().map { entity ->
            entity?.toDomain()
        }
    }

    override suspend fun getPlayer(): Player? {
        return playerDao.getPlayer()?.toDomain()
    }

    override suspend fun savePlayer(player: Player) {
        playerDao.insertPlayer(player.toEntity())
    }

    override suspend fun updateBalance(playerId: String, newBalance: Long) {
        playerDao.updateBalance(playerId, newBalance)
    }

    // --- Mappers ---
    private fun PlayerEntity.toDomain(): Player {
        return Player(
            id = id,
            name = name,
            balance = balance,
            debt = debt,
            garageId = garageId,
            reputation = reputation,
            gameHour = gameHour
        )
    }

    private fun Player.toEntity(): PlayerEntity {
        return PlayerEntity(
            id = id,
            name = name,
            balance = balance,
            debt = debt,
            garageId = garageId,
            reputation = reputation,
            gameHour = gameHour
        )
    }
}