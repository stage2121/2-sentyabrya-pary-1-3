package com.example.data.repository

import com.example.data.local.room.dao.InventoryDao
import com.example.data.local.room.entity.InventoryEntity
import com.example.domain.repository.InventoryItem
import com.example.domain.repository.InventoryRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject

class InventoryRepositoryImpl @Inject constructor(
    private val inventoryDao: InventoryDao
) : InventoryRepository {

    override fun getInventoryFlow(): Flow<List<InventoryItem>> {
        return inventoryDao.getAllItemsFlow().map { entities ->
            entities.map {
                InventoryItem(
                    id = it.id,
                    name = it.name,
                    category = it.category,
                    quality = it.quality,
                    price = it.price,
                    quantity = it.quantity
                )
            }
        }
    }

    override suspend fun addItem(item: InventoryItem) {
        inventoryDao.insertItem(
            InventoryEntity(
                id = item.id,
                name = item.name,
                category = item.category,
                quality = item.quality,
                price = item.price,
                quantity = item.quantity
            )
        )
    }

    override suspend fun removeItem(itemId: String) {
        inventoryDao.deleteItem(itemId)
    }

    override suspend fun removeOneItem(itemId: String) {
        // Уменьшаем количество. Если станет 0, запись можно удалить
        inventoryDao.decrementQuantity(itemId)
    }
}