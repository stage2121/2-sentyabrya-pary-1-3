package com.example.data.local.room.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.local.room.entity.PlayerEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface PlayerDao {
    @Query("SELECT * FROM player LIMIT 1")
    fun getPlayerFlow(): Flow<PlayerEntity?>

    @Query("SELECT * FROM player LIMIT 1")
    suspend fun getPlayer(): PlayerEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlayer(player: PlayerEntity)

    @Query("UPDATE player SET balance = :newBalance WHERE id = :playerId")
    suspend fun updateBalance(playerId: String, newBalance: Long)
}