package com.example.data.local.room.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.domain.model.ListingStatus

@Entity(tableName = "listings")
data class ListingEntity(
    @PrimaryKey val id: String,
    val carId: String,
    val sellerBotId: String,
    val price: Long,
    val createdAtGameHour: Long,
    val status: ListingStatus
)