package com.example.data.local.room.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "player")
data class PlayerEntity(
    @PrimaryKey val id: String,
    val name: String,
    val balance: Long,
    val debt: Long,
    val garageId: String?,
    val reputation: Int,
    val gameHour: Long
)