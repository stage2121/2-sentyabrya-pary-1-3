package com.example.data.di

import android.content.Context
import androidx.room.Room
import com.example.data.local.room.AppDatabase
import com.example.data.local.room.dao.CarDao
import com.example.data.local.room.dao.InventoryDao
import com.example.data.local.room.dao.ListingDao
import com.example.data.local.room.dao.PlayerDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): AppDatabase {
        return Room.databaseBuilder(
            context,
            AppDatabase::class.java,
            "perekup_database"
        ).build()
    }

    @Provides
    fun providePlayerDao(database: AppDatabase): PlayerDao = database.playerDao()

    @Provides
    fun provideCarDao(database: AppDatabase): CarDao = database.carDao()

    @Provides
    fun provideListingDao(database: AppDatabase): ListingDao = database.listingDao()

    // Добавлен метод для предоставления InventoryDao
    @Provides
    fun provideInventoryDao(database: AppDatabase): InventoryDao = database.inventoryDao()
}