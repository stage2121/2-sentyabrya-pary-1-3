package com.example.data.local.room.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.local.room.entity.CarEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface CarDao {
    @Query("SELECT * FROM cars")
    fun getAllCarsFlow(): Flow<List<CarEntity>>

    @Query("SELECT * FROM cars WHERE id = :carId")
    suspend fun getCarById(carId: String): CarEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCar(car: CarEntity)

    @Query("DELETE FROM cars WHERE id = :carId")
    suspend fun deleteCar(carId: String)

    @Query("SELECT * FROM cars WHERE ownerType = 'PLAYER'")
    fun getPlayerCarsFlow(): Flow<List<CarEntity>>

    // Новый запрос для машин, которые продаются на рынке
    @Query("SELECT * FROM cars WHERE ownerType = 'MARKET'")
    fun getMarketCarsFlow(): Flow<List<CarEntity>>
}