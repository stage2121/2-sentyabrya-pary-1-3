package com.example.data.repository

import com.example.data.local.room.dao.CarDao
import com.example.data.local.room.entity.CarEntity
import com.example.domain.model.Car
import com.example.domain.repository.CarRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject

class CarRepositoryImpl @Inject constructor(
    private val carDao: CarDao
) : CarRepository {

    override fun getPlayerCarsFlow(): Flow<List<Car>> {
        return carDao.getPlayerCarsFlow().map { entities ->
            entities.map { it.toDomain() }
        }
    }

    override fun getMarketCarsFlow(): Flow<List<Car>> {
        return carDao.getMarketCarsFlow().map { entities ->
            entities.map { it.toDomain() }
        }
    }

    override suspend fun saveCar(car: Car) {
        carDao.insertCar(car.toEntity())
    }

    override suspend fun getCarById(id: String): Car? {
        return carDao.getCarById(id)?.toDomain()
    }

    override suspend fun deleteCar(carId: String) {
        carDao.deleteCar(carId)
    }

    // --- Mappers ---
    private fun CarEntity.toDomain(): Car {
        return Car(
            id = id,
            brand = brand,
            model = model,
            year = year,
            tier = tier,
            baseValue = baseValue,
            mileage = mileage,
            condition = condition,
            defects = emptyList(),
            photos = emptyList(),
            ownerType = ownerType,
            currentPrice = currentPrice
        )
    }

    private fun Car.toEntity(): CarEntity {
        return CarEntity(
            id = id,
            brand = brand,
            model = model,
            year = year,
            tier = tier,
            baseValue = baseValue,
            mileage = mileage,
            condition = condition,
            ownerType = ownerType,
            currentPrice = currentPrice
        )
    }
}