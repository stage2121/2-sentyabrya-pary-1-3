package com.example.data.local.room.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.local.room.entity.InventoryEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface InventoryDao {
    @Query("SELECT * FROM inventory")
    fun getAllItemsFlow(): Flow<List<InventoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertItem(item: InventoryEntity)

    @Query("DELETE FROM inventory WHERE id = :itemId")
    suspend fun deleteItem(itemId: String)

    // Позже понадобится для ремонта: списать одну запчасть
    @Query("UPDATE inventory SET quantity = quantity - 1 WHERE id = :itemId AND quantity > 0")
    suspend fun decrementQuantity(itemId: String)
}