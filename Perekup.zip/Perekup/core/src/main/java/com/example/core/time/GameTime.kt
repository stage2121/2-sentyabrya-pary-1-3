package com.example.core.time

object GameTime {
    // 1 игровой день = 24 часа
    fun getDay(gameHour: Long): Int = (gameHour / 24).toInt() + 1

    // Час от 0 до 23
    fun getHour(gameHour: Long): Int = (gameHour % 24).toInt()
}