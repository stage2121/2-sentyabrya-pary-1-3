package com.example.core.formulas

import com.example.domain.model.Car
import kotlin.math.max

object Formulas {

    /**
     * Вычисление реальной рыночной стоимости автомобиля (Real Value).
     * Формула из ТЗ (п.5.8).
     */
    fun realValue(car: Car): Long {
        // Фактор состояния: от 0.5 (убитое) до 1.0 (идеал)
        val condFactor = 0.5 + 0.5 * (car.condition / 100.0)

        // Фактор пробега: минимум 0.6 (при пробеге 300 000 км и выше)
        val mileFactor = max(0.6, 1.0 - car.mileage / 300_000.0)

        // Итоговая стоимость: базовая стоимость * факторы
        return (car.baseValue * condFactor * mileFactor).toLong()
    }

    /**
     * Максимальный коэффициент наценки при продаже (из ТЗ п.6).
     * Чем выше тир (премиальнее авто), тем меньше можно накинуть.
     * Значения взяты примерно, их можно будет легко отбалансировать.
     */
    fun maxSaleCoefficient(tier: Int): Double {
        return when (tier) {
            1 -> 1.30
            2 -> 1.25
            3 -> 1.20
            4 -> 1.15
            5 -> 1.10
            else -> 1.0
        }
    }

    /**
     * Стоимость ремонта на СТО для одного дефекта (из ТЗ п.4.6.3).
     * repairCost = baseValue × severity/100 × 0.05 × tierMultiplier
     */
    fun repairCostOnSto(car: Car, severity: Int): Long {
        // Множитель стоимости в зависимости от тира (чем дороже авто, тем дороже ремонт)
        val tierMultiplier = when (car.tier) {
            1 -> 1.0
            2 -> 1.5
            3 -> 2.0
            4 -> 3.0
            5 -> 5.0
            else -> 1.0
        }

        val severityFactor = severity / 100.0
        return (car.baseValue * severityFactor * 0.05 * tierMultiplier).toLong()
    }
}